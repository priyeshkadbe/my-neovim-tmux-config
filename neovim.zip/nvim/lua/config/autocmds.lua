-- Autocmds are automatically loaded on the VeryLazy event
-- Default autocmds that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/autocmds.lua
-- Add any additional autocmds here
--
-- Add autocommand to paste contents of cpp_template.txt into newly created .cpp files
vim.cmd([[
 autocmd FileType *.cpp if !fileexists("%") then exec "!cat ~/.config/nvim/template/cpp_template.txt > %" end
]])

