return {
  -- disable nvim spectrum
  { "windwp/nvim-spectre", enabled = false },
  -- disable nvim-notify
  { "rcarriga/nvim-notify", enabled = false },
}
