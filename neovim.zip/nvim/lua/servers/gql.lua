require("lspconfig").graphql.setup({})
