require("lspconfig").marksman.setup({})
