require("lspconfig").pyright.setup({})
