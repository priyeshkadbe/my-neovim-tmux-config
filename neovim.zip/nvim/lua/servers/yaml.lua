require("lspconfig").yamlls.setup({
  settings = {
    yaml = {
      keyOrdering = false,
    },
  },
})
